import React from 'react'

const Greet = () => <h1>Hello Pallavi</h1>

export default Greet