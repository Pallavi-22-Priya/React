import React from 'react'

function Childcomponent(props) {
  return (
    <div>
      {/*<button onClick={props.greetHandler}> Greet Pallavi</button>88*/}
      <button onClick ={ () => props.greetHandler('child')}>Greet Pallavi</button>
    </div>
  )
}

export default Childcomponent
