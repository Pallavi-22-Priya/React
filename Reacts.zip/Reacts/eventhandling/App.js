import React, { Component } from 'react'
import './App.css';
//import Functionclick from './components/Functionclick'
//import Classclick from './components/Classclick'
import Eventbind from './components/Eventbind'
class  App extends Component {
  render() {
  return (
    <div className="App">
      {/*<Functionclick />
      <Classclick />*/}
      
      <Eventbind />
    </div>
  );
  }
}

export default App;
