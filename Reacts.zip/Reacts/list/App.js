
import './App.css';
import Namelist from './components/Namelist'
function App() {
  return (
    <div className="App">
      <Namelist />
      
    </div>
  );
}

export default App;
