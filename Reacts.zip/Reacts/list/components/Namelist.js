import React from 'react'
import Student from './components/Student'
function Namelist() {
    
    const names = ['Pallavi' ,'Priya','Praneeth']
    const students = [...
   /* const students = (
        {
            id:1001,
            name:'Pallavi',
            age:22,
            skill:'React'
        },
        {
            id:1002,
            name:'Priya',
            age:22,
            skill:'React'
        },
        {
            id:1003,
            name:'Praneeth',
            age:23,
            skill:'Angular'
        }
    )*/


   /* const studentList = students.map(student => <Student student={student} />)//<h2>I am {student.name}. Iam{student.age}  years onload. I know {student.skill} </h2>)*/
    const nameList = names.map(name => <h2>{name}</h2>)
   return  <div> {
          //names.map(name =><h2>{name}</h2>)
          studentList
      }
    </div>
  
}

export default Namelist
